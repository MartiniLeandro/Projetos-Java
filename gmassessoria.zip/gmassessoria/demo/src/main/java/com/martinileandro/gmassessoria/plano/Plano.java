package com.martinileandro.gmassessoria.plano;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.hibernate.annotations.Formula;

import java.math.BigDecimal;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "planos")
public class Plano {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "0 nome não pode ser nulo")
    private String nome;

    @Enumerated(EnumType.STRING)
    @NotNull(message = "O ciclo não pode ser nulo")
    private Ciclo ciclo;

    @NotNull(message = "o valor_base não pode ser nulo")
    private BigDecimal valorBase;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private PlanoStatus planoStatus = PlanoStatus.ATIVO;

    @Enumerated(EnumType.STRING)
    @Column(name = "categoria")
    private PlanoCategoria planoCategoria;

    @Formula("(SELECT COUNT(c.id) FROM contratos c WHERE c.plano_id = id AND c.status = 'ATIVO')")
    private Long quantidadeAlunos;

}
